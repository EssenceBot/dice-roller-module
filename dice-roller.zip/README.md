<div>
    <p align="center">
        <img src="https://s3.fater.dev/common-assets/banner-frame-essence-bot-bg.svg" width="600"></img>
    </p>
</div>

<div align="center">
    <a href='https://jenkins.fater.eu.org/job/Essence%20Bot/job/essence-bot/job/master/'>
        <img src='https://jenkins.fater.eu.org/buildStatus/icon?job=Essence+Bot%2Fessence-bot%2Fmaster&subject=Bot%20build%20status:'>
    </a>
    &nbsp;
    <a href='https://jenkins.fater.eu.org/job/Essence%20Bot/job/essence-bot-docs/job/master/'>
        <img src='https://jenkins.fater.eu.org/buildStatus/icon?job=Essence+Bot%2Fessence-bot-docs%2Fmaster&subject=Docs%20build%20status:'>
    </a>
    &nbsp;
    <a href='https://jenkins.fater.eu.org/job/Essence%20Bot/job/essence-bot-docs/job/master/'>
        <img src='https://jenkins.fater.eu.org/buildStatus/icon?job=Essence+Bot%2Fessence-bot-docs%2Fmaster&subject=Website%20build%20status:'>
    </a>
</div>

# 📜 Table of contents

- [📖 Introduction](#-introduction)
- [🧑‍💻 How to run](#-how-to-run)
  - [📦 Docker](#-docker-recomended)
  - [🖥️ Bare metal](#-bare-metal-not-recomended)
- [📄 Documentation](#-documentation)
- [💬 Help and contact](#-help-and-contact)
- [📃 License](#-license)
- [🤝 Contributors](#-contributors)
- [💖 Support](#-support)

# 📖 Introduction

This is dice roller module for **Essence Bot**. It's inspired by [Throw' em](https://github.com/Faterek/throw-em) discord bot.

# 🧑‍💻 How to use

### 📦 Docker (**recomended**)

### 🖥️ Bare metal (**not recomended**)

# 📄 Documentation

# 💬 Help and contact

# 📃 License

Every component of the bot and any first party modules are licensed under **Open Software License v. 3.0 (OSL-3.0)**

# 🤝 Contributors

**Faterek**
**Narufae**

# 💖 Support
